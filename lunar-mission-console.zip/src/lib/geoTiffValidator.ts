export async function validateGeoTIFF(file: File): Promise<{ isValid: boolean; error?: string }> {
  if (!file) {
    return { isValid: false, error: "No file provided" };
  }

  // Check file extension
  const fileName = file.name.toLowerCase();
  if (!fileName.endsWith('.tif') && !fileName.endsWith('.tiff')) {
    return { isValid: false, error: "Invalid file extension. Expected .tif or .tiff" };
  }

  // Check file size (e.g., minimum 100 bytes to be a valid TIFF with headers)
  if (file.size < 100) {
    return { isValid: false, error: "File is too small to be a valid GeoTIFF" };
  }

  try {
    // Read the first 4 bytes to check the magic number
    const buffer = await file.slice(0, 4).arrayBuffer();
    const view = new DataView(buffer);
    const byte0 = view.getUint8(0);
    const byte1 = view.getUint8(1);
    
    const isLittleEndian = byte0 === 0x49 && byte1 === 0x49; // 'II'
    const isBigEndian = byte0 === 0x4D && byte1 === 0x4D; // 'MM'

    if (!isLittleEndian && !isBigEndian) {
       return { isValid: false, error: "Invalid TIFF magic bytes. Not a valid GeoTIFF file." };
    }

    const version = isLittleEndian ? view.getUint16(2, true) : view.getUint16(2, false);
    
    // 42 (0x2A) for standard TIFF, 43 (0x2B) for BigTIFF
    if (version !== 42 && version !== 43) {
      return { isValid: false, error: "Invalid TIFF version. Not a valid GeoTIFF file." };
    }

    return { isValid: true };
  } catch (error) {
    console.error("Error reading file header:", error);
    return { isValid: false, error: "Failed to read file headers. The file might be corrupted." };
  }
}
