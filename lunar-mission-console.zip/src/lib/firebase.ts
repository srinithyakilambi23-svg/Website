import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth';
import { getFirestore, initializeFirestore, doc, setDoc, getDoc, collection, query, onSnapshot, addDoc, updateDoc } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const googleAuthProvider = new GoogleAuthProvider();
export const db = getFirestore(app, (firebaseConfig as any).firestoreDatabaseId);

// Firestore helper functions
export const usersCollection = collection(db, 'users');
export const missionPlansCollection = collection(db, 'mission_plans');
export const notificationsCollection = collection(db, 'notifications');
