import { useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Stars, Grid } from "@react-three/drei";
import { EffectComposer, Bloom } from "@react-three/postprocessing";
import * as THREE from "three";

function MoonSphere({ showHeatmap, hologramMode = false, onPointClick }: { showHeatmap: boolean, hologramMode?: boolean, onPointClick?: (lat: number, lon: number) => void }) {
  const meshRef = useRef<THREE.Mesh>(null);
  
  useFrame((state, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += delta * 0.05;
    }
  });

  return (
    <mesh 
      ref={meshRef} 
      receiveShadow 
      castShadow
      onClick={(e) => {
        if (e.intersections.length > 0 && e.intersections[0].uv && onPointClick) {
          const uv = e.intersections[0].uv;
          const lon = (uv.x * 360) - 180;
          const lat = (uv.y * 180) - 90;
          onPointClick(lat, lon);
        }
      }}
    >
      <sphereGeometry args={[2, 64, 64]} />
      {/* Holographic material effect */}
      <meshStandardMaterial 
        color={showHeatmap ? "#10b981" : "#00F2FF"} 
        emissive={showHeatmap ? "#3b82f6" : "#00F2FF"}
        emissiveIntensity={hologramMode ? 2.0 : (showHeatmap ? 0.5 : 0.2)}
        wireframe={true}
        transparent
        opacity={showHeatmap ? 0.3 : 0.15}
      />
      {/* Solid inner core to give it substance */}
      <mesh scale={0.99}>
        <sphereGeometry args={[2, 32, 32]} />
        <meshStandardMaterial 
          color={showHeatmap ? "#1e1b4b" : "#0f172a"} 
          roughness={0.8}
          metalness={0.2}
        />
      </mesh>
    </mesh>
  );
}

function Particles() {
  const pointsRef = useRef<THREE.Points>(null);
  const [positions] = useState(() => {
    const pos = new Float32Array(500 * 3);
    for (let i = 0; i < 500; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);
      const r = 2.2 + Math.random() * 1.5;
      
      pos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      pos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      pos[i * 3 + 2] = r * Math.cos(phi);
    }
    return pos;
  });

  useFrame((state, delta) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y -= delta * 0.02;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute 
          attach="attributes-position"
          count={positions.length / 3}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial size={0.02} color="#00F2FF" transparent opacity={0.4} />
    </points>
  );
}

export function HoloMoon({ showHeatmap = false, hologramMode = false, onPointClick }: { showHeatmap?: boolean, hologramMode?: boolean, onPointClick?: (lat: number, lon: number) => void }) {
  return (
    <div className="w-full h-full absolute inset-0 bg-black flex flex-col pointer-events-auto">
      <Canvas camera={{ position: [0, 2, 6], fov: 45 }}>
        <color attach="background" args={[hologramMode ? "#000000" : "#020617"]} />
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1} color="#00F2FF" />
        <spotLight position={[-10, 10, -10]} intensity={0.5} color="#00F2FF" />
        
        {!hologramMode && <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />}
        
        <MoonSphere showHeatmap={showHeatmap} hologramMode={hologramMode} onPointClick={onPointClick} />
        <Particles />
        
        {/* Animated grid beneath moon */}
        {!hologramMode && (
          <Grid 
            position={[0, -3, 0]}
            args={[20, 20]}
            cellSize={0.5}
            cellThickness={1}
            cellColor="#00F2FF"
            sectionSize={2.5}
            sectionThickness={1.5}
            sectionColor="#00F2FF"
            fadeDistance={10}
            fadeStrength={1}
          />
        )}
        
        <OrbitControls 
          enablePan={!hologramMode}
          enableZoom={!hologramMode}
          enableRotate={!hologramMode}
          autoRotate={hologramMode}
          autoRotateSpeed={2}
          maxDistance={15}
          minDistance={3}
        />
        
        {hologramMode && (
          <EffectComposer>
            <Bloom luminanceThreshold={0} luminanceSmoothing={0.9} height={300} intensity={1.5} />
          </EffectComposer>
        )}
      </Canvas>
      
      {/* Map Controls Overlay */}
      {!hologramMode && (
        <div className="absolute bottom-16 left-8 flex flex-col gap-2 pointer-events-auto">
           <div className="flex flex-col border border-slate-800 bg-slate-900/80 rounded-sm overflow-hidden">
              <button className="p-2 hover:bg-[#00F2FF20] border-b border-slate-800 text-slate-300">
                 <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v12M6 12h12"/></svg>
              </button>
              <button className="p-2 hover:bg-[#00F2FF20] border-b border-slate-800 text-slate-300">
                 <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 12H4"/></svg>
              </button>
              <button className="p-2 hover:bg-[#00F2FF20] text-slate-300">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L4.5 20.29L5.21 21L12 18L18.79 21L19.5 20.29L12 2Z"/></svg>
              </button>
           </div>
           <button className="bg-[#00F2FF10] border border-[#00F2FF40] p-2 rounded-sm text-[#00F2FF] text-[10px] font-mono tracking-widest hover:bg-[#00F2FF20]">RESET CAMERA</button>
        </div>
      )}
    </div>
  );
}
