import { Link, useLocation } from "react-router-dom";
import { 
  LayoutDashboard, 
  Target, 
  MapPin, 
  Navigation, 
  Database, 
  FileText, 
  Box, 
  Settings 
} from "lucide-react";
import { cn } from "../lib/utils";

const NAV_ITEMS = [
  { name: "Dashboard", path: "/", icon: LayoutDashboard },
  { name: "Ice Detection", path: "/ice-detection", icon: Target },
  { name: "Landing Assessment", path: "/landing-assessment", icon: MapPin },
  { name: "Rover Planning", path: "/rover-planning", icon: Navigation },
  { name: "Data Explorer", path: "/data", icon: Database },
  { name: "Reports", path: "/reports", icon: FileText },
  { name: "Holographic Projection", path: "/holographic-projection", icon: Box },
  { name: "Settings", path: "/settings", icon: Settings },
];

export function Sidebar() {
  const location = useLocation();

  return (
    <aside className="w-64 bg-[#050810] border-r border-slate-800 flex flex-col h-full text-slate-300 shrink-0">
      <div className="p-6 border-b border-slate-800 flex flex-col items-center gap-4">
        <div className="w-10 h-10 bg-[#FF9933] rounded-sm flex items-center justify-center font-bold text-black text-xs shrink-0">
          ISRO
        </div>
      </div>
      
      <nav className="flex-1 overflow-y-auto py-6">
        <ul className="space-y-2 px-4">
          {NAV_ITEMS.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            return (
              <li key={item.name}>
                <Link
                  to={item.path}
                  className={cn(
                    "flex items-center space-x-3 px-3 py-2.5 rounded-sm text-sm transition-colors",
                    isActive 
                      ? "bg-[#00F2FF20] text-[#00F2FF] border border-[#00F2FF40]" 
                      : "text-slate-500 hover:text-slate-300 hover:bg-slate-800/50 border border-transparent"
                  )}
                >
                  <Icon className="w-4 h-4" />
                  <span className="font-medium text-[11px] tracking-wide uppercase">{item.name}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="p-4 mb-2">
        <div className="bg-slate-900/40 rounded-sm p-3 border border-slate-800">
          <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold mb-1">System Status</div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            <span className="text-xs text-green-500 font-mono uppercase tracking-wider">Operational</span>
          </div>
        </div>
      </div>
    </aside>
  );
}
