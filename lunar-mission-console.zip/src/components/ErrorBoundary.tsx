import React, { Component, ErrorInfo, ReactNode } from "react";
import { AlertTriangle, RefreshCw } from "lucide-react";

interface Props {
  children?: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }
      
      return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-[#020408] text-slate-300 p-6 absolute inset-0 z-50">
          <div className="max-w-md w-full bg-[#050810] border border-red-500/30 rounded-sm p-8 text-center shadow-[0_0_30px_rgba(239,68,68,0.1)]">
            <div className="w-16 h-16 rounded-full border border-red-500/30 flex items-center justify-center mx-auto mb-6 bg-red-500/10">
              <AlertTriangle className="w-8 h-8 text-red-500" />
            </div>
            <h2 className="text-sm font-bold text-red-400 uppercase tracking-widest mb-3">Subsystem Failure</h2>
            <div className="bg-slate-900/80 border border-slate-800 p-4 mb-6 rounded-sm text-left">
              <div className="text-[10px] text-slate-500 uppercase tracking-widest mb-1">Diagnostic Logs</div>
              <p className="text-[11px] font-mono text-slate-300 break-words">
                {this.state.error?.message || "An unexpected error occurred during lunar analysis processing."}
              </p>
            </div>
            <button 
              onClick={() => {
                this.setState({ hasError: false, error: null });
                window.location.reload();
              }}
              className="w-full bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/50 py-3 rounded-sm text-[11px] font-mono tracking-widest uppercase transition-colors flex items-center justify-center"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Reboot Subsystem
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
