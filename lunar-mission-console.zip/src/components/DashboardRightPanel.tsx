import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { CheckCircle2, Circle, AlertTriangle, Info, ShieldAlert } from "lucide-react";
import { cn } from "../lib/utils";

export function DashboardRightPanel({ currentCoords = { lat: -89.9, lon: 129.1 } }: { currentCoords?: { lat: number, lon: number } }) {
  const [regionData, setRegionData] = useState<any>(null);

  useEffect(() => {
    let mounted = true;
    fetch(`/api/region-analysis?lat=${currentCoords.lat}&lon=${currentCoords.lon}`)
      .then(res => {
        if (!res.ok) throw new Error("Server error");
        return res.json();
      })
      .then(data => {
        if (mounted) setRegionData(data);
      })
      .catch(err => {
        console.warn("Failed to fetch region data:", err);
        if (mounted) {
           setRegionData({
             confidence: 87,
             terrainSlope: 2.4,
             terrainRoughness: 12,
             riskLevel: 'Safe',
             distanceToIce: 1.4,
             illumination: 92,
             iceProbability: 72,
             temperature: 42
           });
        }
      });
    return () => { mounted = false; };
  }, [currentCoords]);

  const steps = [
    { name: "Data Acquisition", completed: true },
    { name: "Ice Detection", completed: true },
    { name: "Landing Assessment", completed: true },
    { name: "Rover Planning", completed: false },
    { name: "XAI Reports", completed: false },
    { name: "Holographic Projection", completed: false },
  ];

  if (!regionData) {
     return <div className="w-[320px] bg-[#050810] border-l border-slate-800 h-full overflow-y-auto p-4 flex items-center justify-center absolute right-0 top-0 text-[#00F2FF] font-mono text-[10px]">Loading telemetry...</div>;
  }

  return (
    <div className="w-[320px] bg-[#050810] border-l border-slate-800 h-full overflow-y-auto p-4 flex flex-col gap-4 absolute right-0 top-0 pointer-events-auto z-10 no-scrollbar">
      
      {/* Ice Confidence */}
      <section className="bg-slate-900/40 border border-slate-800 rounded-sm p-4">
        <h3 className="text-[11px] font-bold uppercase text-slate-400 tracking-widest mb-4">Ice Confidence Profile</h3>
        <div className="flex items-center gap-4">
          <div className="relative w-20 h-20">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="8" className="text-slate-800" />
              <motion.circle 
                cx="50" cy="50" r="45" 
                fill="none" 
                stroke="currentColor"
                className="text-[#00F2FF]"
                strokeWidth="8"
                strokeLinecap="round"
                initial={{ strokeDasharray: "0 300" }}
                animate={{ strokeDasharray: `${(regionData.confidence / 100) * 282} 300` }}
                transition={{ duration: 1.5, ease: "easeOut" }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="font-mono text-xl">{regionData.confidence}%</span>
            </div>
          </div>
          <div className="flex-1 flex flex-col gap-1">
             <div className="text-[10px] text-slate-500">PROBABILITY INDEX</div>
             <div className="text-xs font-semibold text-green-400">{regionData.confidence > 75 ? "HIGH" : regionData.confidence > 40 ? "MEDIUM" : "LOW"} CONFIDENCE</div>
             <div className="h-1 bg-slate-800 w-full mt-2">
                <div className={cn("h-full w-full", regionData.confidence > 75 ? "bg-green-400" : regionData.confidence > 40 ? "bg-yellow-400" : "bg-red-400")} style={{ width: `${regionData.confidence}%` }}></div>
             </div>
          </div>
        </div>
      </section>

      {/* Landing Risk */}
      <section className="bg-slate-900/40 border border-slate-800 rounded-sm p-4 flex flex-col gap-3">
         <h3 className="text-[11px] font-bold uppercase text-slate-400 tracking-widest">Landing Risk Matrix</h3>
         <div className="flex justify-between items-center">
            <span className="text-xs text-slate-300">Terrain Slope</span>
            <span className={cn("text-xs font-mono", regionData.terrainSlope < 10 ? "text-green-400" : "text-yellow-400")}>{regionData.terrainSlope}° ({regionData.terrainSlope < 10 ? "SAFE" : "MED"})</span>
         </div>
         <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full bg-green-500" style={{ width: `${Math.min(100, regionData.terrainSlope * 5)}%` }}></div>
         </div>
         
         <div className="flex justify-between items-center">
            <span className="text-xs text-slate-300">Terrain Roughness</span>
            <span className="text-xs font-mono text-yellow-400">{regionData.terrainRoughness}%</span>
         </div>
         <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full bg-yellow-500" style={{ width: `${regionData.terrainRoughness}%` }}></div>
         </div>
         
         <div className="flex justify-between items-center">
            <span className="text-xs text-slate-300">Risk Level</span>
            <span className={cn("text-xs font-mono font-bold", regionData.riskLevel === 'Danger' ? 'text-red-400' : 'text-green-400')}>{regionData.riskLevel.toUpperCase()}</span>
         </div>
         <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div className={cn("h-full", regionData.riskLevel === 'Danger' ? 'bg-red-500' : 'bg-green-500')} style={{ width: regionData.riskLevel === 'Danger' ? '90%' : '20%' }}></div>
         </div>
      </section>

      {/* Statistics Cards */}
      <section className="flex flex-col gap-2">
         <div className="grid grid-cols-2 gap-2">
            <div className="bg-slate-900/40 border border-slate-800 p-3 rounded-sm">
               <div className="text-[9px] text-slate-500 uppercase">Distance to Ice</div>
               <div className="text-lg font-mono text-slate-200">{regionData.distanceToIce}km</div>
            </div>
            <div className="bg-slate-900/40 border border-slate-800 p-3 rounded-sm">
               <div className="text-[9px] text-slate-500 uppercase">Illumination</div>
               <div className="text-lg font-mono text-slate-200">{regionData.illumination}%</div>
            </div>
         </div>
         <div className="bg-slate-900/40 border border-slate-800 p-3 rounded-sm">
            <div className="text-[9px] text-slate-500 uppercase mb-2">SHAP Feature Importance</div>
            <div className="flex flex-col gap-1">
               <div className="flex items-center gap-2">
                  <div className="w-12 text-[8px] text-slate-400 font-mono">OHRC_SR</div>
                  <div className="flex-1 h-2 bg-[#00F2FF30]"><div className="h-full bg-[#00F2FF]" style={{ width: `${Math.round(regionData.iceProbability * 0.7)}%` }}></div></div>
               </div>
               <div className="flex items-center gap-2">
                  <div className="w-12 text-[8px] text-slate-400 font-mono">DIV_TEMP</div>
                  <div className="flex-1 h-2 bg-orange-400/30"><div className="h-full bg-orange-400" style={{ width: `${Math.round(regionData.temperature * 0.6)}%` }}></div></div>
               </div>
            </div>
         </div>
      </section>

      {/* Mission Workflow */}
      <section className="mt-auto border-t border-slate-800 pt-4">
         <h3 className="text-[11px] font-bold uppercase text-slate-400 tracking-widest mb-4">Mission Workflow</h3>
         <div className="flex flex-col gap-3">
            {steps.map((step, idx) => (
              <div key={idx} className={cn("flex items-center gap-3", !step.completed && "opacity-30")}>
                 {step.completed ? (
                   <div className="w-5 h-5 rounded-full bg-[#00F2FF] flex items-center justify-center text-black font-bold text-[10px]">✓</div>
                 ) : (
                   <div className="w-5 h-5 rounded-full border border-slate-600 flex items-center justify-center text-slate-600 text-[10px]">{idx + 1}</div>
                 )}
                 <span className={cn("text-xs", step.completed ? "text-[#00F2FF]" : "text-slate-500")}>
                    {step.name}
                 </span>
              </div>
            ))}
         </div>
      </section>

    </div>
  );
}
