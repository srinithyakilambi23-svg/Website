import { Bell, User, Map, Search, LogOut } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useState, useEffect } from "react";
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../lib/firebase";

export function Header() {
  const { user, profile, signIn, signOut } = useAuth();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, "notifications"), orderBy("createdAt", "desc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const notifs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setNotifications(notifs);
    }, (error) => {
      // Silently ignore if firestore rules are not set
    });
    return () => unsubscribe();
  }, [user]);

  const triggerTestNotification = async () => {
    try {
      await addDoc(collection(db, "notifications"), {
        message: "Data Processing Complete: DFSAR_GRID_72",
        type: "success",
        createdAt: serverTimestamp()
      });
    } catch(e) {
      console.error("Error triggering test notification:", e);
    }
  };

  return (
    <header className="h-16 border-b border-slate-800 bg-[#050810] flex items-center justify-between px-6 sticky top-0 z-10 shrink-0">
      <div className="flex items-center gap-4">
        <h1 className="text-lg font-semibold tracking-tight text-slate-200 uppercase hidden md:flex items-center">
          Lunar Mission Console 
          <span className="text-[#00F2FF] ml-3 text-[10px] font-mono px-2 py-0.5 border border-[#00F2FF40] bg-[#00F2FF10] rounded-sm">V.2.6-ALPHA</span>
        </h1>
        <div className="relative group ml-4 hidden lg:block">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input 
            type="text" 
            placeholder="Search coordinates, craters, datasets..."
            className="bg-slate-900/50 border border-slate-800 text-[11px] rounded-sm pl-9 pr-4 py-1.5 focus:outline-none focus:ring-1 focus:ring-[#00F2FF50] w-64 text-slate-200 placeholder:text-slate-600 transition-all focus:w-80 font-mono uppercase tracking-wider"
          />
        </div>
      </div>

      <div className="flex items-center gap-6 relative">
        <div className="flex items-center gap-3 bg-slate-900/50 border border-slate-800 px-3 py-1.5 rounded-sm">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
          <span className="text-[10px] font-mono uppercase text-slate-400 tracking-wider">Region: Shackleton Crater S.P.</span>
        </div>
        
        <div className="flex items-center gap-4 border-l border-slate-800 pl-6">
          <button 
            className="relative p-1 text-slate-500 hover:text-slate-300 transition-colors"
            onClick={() => {
              setShowNotifications(!showNotifications);
              setShowProfile(false);
            }}
          >
            <Bell className="w-4 h-4" />
            {notifications.length > 0 && (
              <span className="absolute top-0 right-0 w-1.5 h-1.5 bg-[#00F2FF] rounded-full"></span>
            )}
          </button>
          
          {user ? (
            <button 
              className="relative w-8 h-8 rounded-sm bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold text-slate-300 overflow-hidden cursor-pointer hover:border-slate-500 transition-colors"
              onClick={() => {
                setShowProfile(!showProfile);
                setShowNotifications(false);
              }}
            >
              {user.photoURL ? (
                <img src={user.photoURL} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                (user.displayName?.[0] || user.email?.[0] || 'U').toUpperCase()
              )}
            </button>
          ) : (
            <button 
              onClick={signIn}
              className="px-3 py-1.5 bg-[#00F2FF10] border border-[#00F2FF40] text-[#00F2FF] rounded-sm text-[10px] font-mono tracking-widest uppercase hover:bg-[#00F2FF20] transition-colors"
            >
              Authenticate
            </button>
          )}
        </div>

        {/* Notifications Dropdown */}
        {showNotifications && (
          <div className="absolute top-12 right-12 w-80 bg-[#050810] border border-slate-800 shadow-2xl rounded-sm z-50">
            <div className="p-3 border-b border-slate-800 flex justify-between items-center">
              <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">System Events</span>
              <button onClick={triggerTestNotification} className="text-[9px] text-[#00F2FF] hover:underline font-mono uppercase">Trigger Test</button>
            </div>
            <div className="max-h-64 overflow-y-auto no-scrollbar">
              {notifications.length === 0 ? (
                <div className="p-4 text-center text-[10px] text-slate-500 font-mono uppercase">No recent events</div>
              ) : (
                notifications.map((n, i) => (
                  <div key={i} className="p-3 border-b border-slate-800/50 hover:bg-slate-900/50 transition-colors">
                    <div className="text-[10px] text-slate-300 font-mono">{n.message}</div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Profile Dropdown */}
        {showProfile && user && (
          <div className="absolute top-12 right-0 w-64 bg-[#050810] border border-slate-800 shadow-2xl rounded-sm z-50 p-4">
            <div className="flex items-center gap-3 mb-4 pb-4 border-b border-slate-800">
              <div className="w-10 h-10 rounded-sm bg-slate-800 overflow-hidden">
                {user.photoURL && <img src={user.photoURL} alt="Avatar" className="w-full h-full object-cover" />}
              </div>
              <div>
                <div className="text-xs font-bold text-slate-200">{user.displayName || 'Unknown Operator'}</div>
                <div className="text-[10px] text-[#00F2FF] font-mono uppercase tracking-widest mt-1">
                  ROLE: {profile?.role || 'pending'}
                </div>
              </div>
            </div>
            <button 
              onClick={signOut}
              className="w-full flex items-center justify-center gap-2 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-red-400 text-[10px] font-mono uppercase tracking-widest rounded-sm transition-colors"
            >
              <LogOut className="w-3 h-3" />
              Disconnect
            </button>
          </div>
        )}

      </div>
    </header>
  );
}
