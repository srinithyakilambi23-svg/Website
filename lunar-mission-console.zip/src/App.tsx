/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { MainLayout } from "./layouts/MainLayout";
import { Dashboard } from "./pages/Dashboard";
import { IceDetection } from "./pages/IceDetection";
import { LandingAssessment } from "./pages/LandingAssessment";
import { RoverPlanning } from "./pages/RoverPlanning";
import { Reports } from "./pages/Reports";
import { HolographicProjection } from "./pages/HolographicProjection";
import { AuthProvider } from "./context/AuthContext";
import { ErrorBoundary } from "./components/ErrorBoundary";

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <MainLayout>
            <ErrorBoundary>
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/ice-detection" element={<IceDetection />} />
                <Route path="/landing-assessment" element={<LandingAssessment />} />
                <Route path="/rover-planning" element={<RoverPlanning />} />
                <Route path="/reports" element={<Reports />} />
                <Route path="/holographic-projection" element={<HolographicProjection />} />
                {/* Settings and Data Explorer can just fall back to Dashboard or dummy pages if needed, mapping to Dashboard for now to prevent 404 */}
                <Route path="*" element={<Dashboard />} />
              </Routes>
            </ErrorBoundary>
        </MainLayout>
      </Router>
    </AuthProvider>
  );
}

