import { HoloMoon } from "../components/HoloMoon";

export function HolographicProjection() {
  return (
    <div className="w-full h-full bg-black relative flex items-center justify-center overflow-hidden">
      
      {/* Instructions Overlay */}
      <div className="absolute top-6 left-6 text-[#00F2FF] opacity-50 z-20 pointer-events-none">
        <h2 className="text-sm font-bold uppercase tracking-widest mb-1">Holographic Array Active</h2>
        <p className="text-[10px] font-mono uppercase">Place transparent pyramid in center.</p>
      </div>

      {/* Holographic Views Container */}
      <div className="relative w-[90vmin] h-[90vmin] max-w-[800px] max-h-[800px]">
        {/* Alignment Center Point */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 border border-[#00F2FF]/30 rounded-full z-10 pointer-events-none flex items-center justify-center">
          <div className="w-1 h-1 bg-[#00F2FF] rounded-full animate-pulse"></div>
        </div>

        {/* Top View */}
        <div className="absolute bottom-1/2 left-1/4 w-1/2 h-1/2 rotate-180">
          <HoloMoon hologramMode={true} />
        </div>

        {/* Bottom View */}
        <div className="absolute top-1/2 left-1/4 w-1/2 h-1/2">
          <HoloMoon hologramMode={true} />
        </div>

        {/* Left View */}
        <div className="absolute top-1/4 right-1/2 w-1/2 h-1/2 rotate-90">
          <HoloMoon hologramMode={true} />
        </div>

        {/* Right View */}
        <div className="absolute top-1/4 left-1/2 w-1/2 h-1/2 -rotate-90">
          <HoloMoon hologramMode={true} />
        </div>
      </div>
    </div>
  );
}
