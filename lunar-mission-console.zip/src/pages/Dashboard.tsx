import { useState, useEffect } from "react";
import { HoloMoon } from "../components/HoloMoon";
import { DashboardRightPanel } from "../components/DashboardRightPanel";

export function Dashboard() {
  const [coords, setCoords] = useState({ lat: -89.9, lon: 129.1 });

  const handlePointClick = (lat: number, lon: number) => {
    setCoords({ lat: parseFloat(lat.toFixed(1)), lon: parseFloat(lon.toFixed(1)) });
  };

  return (
    <div className="w-full h-full relative overflow-hidden bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#0A1120] to-[#020408]">
      {/* 3D Map Background */}
      <HoloMoon onPointClick={handlePointClick} />
      
      {/* Floating Info Overlay */}
      <div className="absolute top-8 left-8 pointer-events-none">
        <div className="bg-black/60 border-l-2 border-[#00F2FF] p-3 backdrop-blur-sm pointer-events-auto">
          <div className="text-[10px] uppercase tracking-wider text-slate-400">Scanning Status</div>
          <div className="text-xs font-mono text-[#00F2FF] mt-1 flex items-center gap-2">
            <span className="w-1 h-3 bg-[#00F2FF] animate-pulse"></span>
            ACTIVE_SCAN: DFSAR_GRID_72
          </div>
        </div>
        <div className="flex gap-2 mt-4 pointer-events-auto">
          <span className="px-2 py-1 bg-slate-800 border border-slate-700 text-[10px] font-mono">LAT: {Math.abs(coords.lat)}°{coords.lat >= 0 ? 'N' : 'S'}</span>
          <span className="px-2 py-1 bg-slate-800 border border-slate-700 text-[10px] font-mono">LNG: {Math.abs(coords.lon)}°{coords.lon >= 0 ? 'E' : 'W'}</span>
        </div>
      </div>

      {/* Right Panel */}
      <DashboardRightPanel currentCoords={coords} />
      
      {/* Footer Status */}
      <footer className="absolute bottom-0 left-0 right-[320px] h-10 border-t border-slate-800 bg-[#020408] flex items-center justify-between px-6 shrink-0 z-10 pointer-events-auto">
        <div className="flex items-center gap-6">
          <div className="text-[9px] text-slate-500 uppercase tracking-widest font-mono">System Status: <span className="text-green-500">OPERATIONAL</span></div>
          <div className="text-[9px] text-slate-500 uppercase tracking-widest font-mono">Data Source: CHANDRAYAAN-2 / LOLA / M³</div>
        </div>
        <div className="flex items-center gap-4">
           <button className="px-3 py-1 bg-white hover:bg-slate-200 text-black rounded-sm text-[10px] font-bold uppercase tracking-tighter">
             Export Mission Report
           </button>
        </div>
      </footer>
    </div>
  );
}
