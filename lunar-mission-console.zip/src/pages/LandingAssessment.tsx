import { useState } from "react";
import { HoloMoon } from "../components/HoloMoon";
import { Crosshair, ShieldCheck, Download, Save, TriangleAlert, Sun, MapPin, Maximize } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../lib/utils";

const SITES = [
  { id: "site-a", name: "Shackleton Rim (Primary)", lat: -89.9, lon: 129.1, coords: "89.9° S, 129.1° E", risk: "low" },
  { id: "site-b", name: "Amundsen Crater (Backup)", lat: -84.5, lon: 82.8, coords: "84.5° S, 82.8° E", risk: "medium" },
  { id: "site-c", name: "Haworth Crater", lat: -87.4, lon: -4.2, coords: "87.4° S, 4.2° W", risk: "high" },
];

export function LandingAssessment() {
  const [activeSite, setActiveSite] = useState(SITES[0].id);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [regionData, setRegionData] = useState<any>(null);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    setShowResults(false);
    
    const site = SITES.find(s => s.id === activeSite) || SITES[0];
    
    try {
      const res = await fetch(`/api/region-analysis?lat=${site.lat}&lon=${site.lon}`);
      const data = await res.json();
      
      setTimeout(() => {
        setRegionData(data);
        setIsAnalyzing(false);
        setShowResults(true);
      }, 2000);
    } catch (e) {
      console.error(e);
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="w-full h-full relative overflow-hidden bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#0A1120] to-[#020408]">
      <HoloMoon />
      
      {/* Targeting Reticle Overlay Simulation */}
      <AnimatePresence>
        {isAnalyzing && (
          <motion.div 
            initial={{ scale: 2, opacity: 0 }}
            animate={{ scale: 1, opacity: 1, rotate: 90 }}
            exit={{ scale: 0.5, opacity: 0 }}
            transition={{ duration: 1 }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none"
          >
            <div className="w-64 h-64 border border-dashed border-[#00F2FF] rounded-full animate-spin-slow flex items-center justify-center bg-[#00F2FF05]">
              <Crosshair className="w-16 h-16 text-[#00F2FF] opacity-50" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="absolute left-8 top-8 bottom-16 w-[360px] bg-[#050810]/90 backdrop-blur-xl border border-slate-800 rounded-sm p-5 flex flex-col pointer-events-auto shadow-2xl z-10">
        <h2 className="text-sm font-bold text-slate-200 mb-6 flex items-center uppercase tracking-widest">
          <Crosshair className="w-4 h-4 mr-2 text-green-400" />
          Landing Site Assessment
        </h2>

        <div className="mb-6">
          <h3 className="text-[10px] font-bold text-slate-500 mb-3 uppercase tracking-widest">Candidate Sites</h3>
          <div className="space-y-2">
            {SITES.map(site => (
              <button
                key={site.id}
                onClick={() => { setActiveSite(site.id); setShowResults(false); }}
                className={cn(
                  "w-full text-left px-4 py-3 rounded-sm border transition-all duration-200",
                  activeSite === site.id 
                    ? "bg-slate-900/80 border-slate-700 shadow-md" 
                    : "bg-slate-900/30 border-slate-800 hover:bg-slate-900/60"
                )}
              >
                <div className="flex justify-between items-start mb-1">
                  <span className={cn("font-medium text-xs tracking-wide uppercase", activeSite === site.id ? "text-green-400" : "text-slate-300")}>
                    {site.name}
                  </span>
                  <div className={cn(
                    "w-1.5 h-1.5 rounded-full mt-1",
                    site.risk === "low" ? "bg-green-500" : site.risk === "medium" ? "bg-yellow-500" : "bg-red-500"
                  )}></div>
                </div>
                <div className="text-[10px] text-slate-500 font-mono tracking-widest">{site.coords}</div>
              </button>
            ))}
          </div>
          
          <button className="w-full mt-3 flex items-center justify-center text-[10px] font-mono tracking-widest uppercase text-slate-500 hover:text-[#00F2FF] py-2 border border-dashed border-slate-700 rounded-sm transition-colors hover:bg-[#00F2FF05]">
            <Maximize className="w-3 h-3 mr-2" />
            Draw Custom Ellipse
          </button>
        </div>

        <div className="pt-4 border-t border-slate-800 mt-auto space-y-3">
          <button 
            onClick={handleAnalyze}
            disabled={isAnalyzing}
            className="w-full bg-green-500/10 hover:bg-green-500/20 disabled:bg-slate-800 border border-green-500/40 text-green-400 font-mono text-[11px] uppercase tracking-widest py-3 rounded-sm transition-colors flex items-center justify-center relative overflow-hidden"
          >
            {isAnalyzing ? (
              <span className="flex items-center">
                <ShieldCheck className="w-4 h-4 mr-2 animate-pulse text-green-300" />
                Scanning Terrain...
              </span>
            ) : (
              <span className="flex items-center">
                <ShieldCheck className="w-4 h-4 mr-2" />
                Analyze Site Safety
              </span>
            )}
             {isAnalyzing && (
              <motion.div 
                className="absolute left-0 top-0 bottom-0 bg-green-500/20" 
                initial={{ width: "0%" }}
                animate={{ width: "100%" }}
                transition={{ duration: 2 }}
              />
            )}
          </button>
          
          <div className="flex space-x-2">
            <button className="flex-1 bg-slate-900 hover:bg-slate-800 text-slate-300 py-2 rounded-sm text-[10px] font-mono tracking-widest uppercase transition-colors border border-slate-800 flex items-center justify-center">
              <Save className="w-3 h-3 mr-1" />
              Save Site
            </button>
            <button className="flex-1 bg-slate-900 hover:bg-slate-800 text-[#00F2FF] py-2 rounded-sm text-[10px] font-mono tracking-widest uppercase transition-colors border border-[#00F2FF30] flex items-center justify-center">
              <Download className="w-3 h-3 mr-1" />
              Export
            </button>
          </div>
        </div>
      </div>

      {/* Results Panel */}
      <AnimatePresence>
        {showResults && regionData && (
          <motion.div 
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 50, opacity: 0 }}
            className="absolute right-8 top-8 bottom-16 w-80 bg-[#050810]/95 backdrop-blur-xl border border-slate-800 rounded-sm p-5 flex flex-col pointer-events-auto shadow-2xl z-10"
          >
            <div className="flex items-center justify-between mb-6 border-b border-slate-800 pb-4">
              <h3 className="font-bold text-slate-200 text-sm tracking-widest uppercase">Report</h3>
              <span className={cn("px-2 py-0.5 text-[10px] font-mono rounded-sm border", regionData.riskLevel === 'Danger' ? "bg-red-500/20 text-red-400 border-red-500/50" : "bg-green-500/20 text-green-400 border-green-500/50")}>
                {regionData.riskLevel === 'Danger' ? "ABORT LANDING" : "GO FOR LANDING"}
              </span>
            </div>

            <div className="space-y-4 flex-1">
              {/* Overall Score */}
              <div className="bg-slate-900/50 rounded-sm p-4 border border-slate-800 text-center">
                <div className="text-[10px] uppercase font-bold tracking-widest text-slate-500 mb-2">Safety Score</div>
                <div className={cn("text-4xl font-mono font-bold", regionData.riskLevel === 'Danger' ? "text-red-400" : "text-green-400")}>
                  {100 - regionData.terrainSlope * 2 - regionData.terrainRoughness}<span className="text-sm opacity-50">/100</span>
                </div>
              </div>

              {/* Metrics */}
              <div className="space-y-2">
                <div className="flex items-center justify-between p-3 bg-slate-900/40 rounded-sm border border-slate-800">
                  <div className="flex items-center text-slate-400 text-[11px] uppercase tracking-wider">
                    <TriangleAlert className="w-3 h-3 mr-2 text-slate-500" />
                    Terrain Roughness
                  </div>
                  <span className={cn("font-mono text-xs", regionData.terrainRoughness < 10 ? "text-green-400" : "text-yellow-400")}>{regionData.terrainRoughness}%</span>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-slate-900/40 rounded-sm border border-slate-800">
                  <div className="flex items-center text-slate-400 text-[11px] uppercase tracking-wider">
                    <Sun className="w-3 h-3 mr-2 text-yellow-500" />
                    Illumination
                  </div>
                  <span className="text-yellow-400 font-mono text-xs">{regionData.illumination}%</span>
                </div>

                <div className="flex items-center justify-between p-3 bg-slate-900/40 rounded-sm border border-slate-800">
                  <div className="flex items-center text-slate-400 text-[11px] uppercase tracking-wider">
                    <MapPin className="w-3 h-3 mr-2 text-[#00F2FF]" />
                    Dist. to Ice
                  </div>
                  <span className="text-[#00F2FF] font-mono text-xs">{regionData.distanceToIce} km</span>
                </div>
              </div>

              {/* Hazard Map */}
              <div className="mt-6">
                <div className="text-[10px] font-bold text-slate-500 mb-2 uppercase tracking-widest">Detected Hazards</div>
                <div className="h-32 bg-slate-900 rounded-sm relative overflow-hidden border border-slate-800">
                  <div className="absolute inset-0 opacity-20 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-700 via-slate-800 to-[#050810]"></div>
                  {/* Procedurally place hazards based on risk */}
                  {regionData.riskLevel !== 'Safe' && (
                    <>
                      <div className="absolute top-1/4 left-1/3 w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_8px_red]"></div>
                      <div className="absolute bottom-1/3 right-1/4 w-1.5 h-1.5 rounded-full bg-yellow-500 shadow-[0_0_8px_orange]"></div>
                    </>
                  )}
                  {regionData.riskLevel === 'Danger' && (
                     <div className="absolute top-1/2 right-1/3 w-2 h-2 rounded-full bg-red-600 shadow-[0_0_12px_red]"></div>
                  )}
                  {/* Landing Ellipse */}
                  <div className={cn("absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-24 border rounded-[50%]", regionData.riskLevel === 'Danger' ? "border-red-500/50 bg-red-500/5" : "border-green-500/50 bg-green-500/5")}></div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
