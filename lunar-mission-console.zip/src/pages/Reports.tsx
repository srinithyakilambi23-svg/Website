import { useState, useEffect } from "react";
import { FileText, Download, Share2, FileJson, FileSpreadsheet, CheckCircle2 } from "lucide-react";
import { motion } from "motion/react";
import { cn } from "../lib/utils";

export function Reports() {
  const [reportData, setReportData] = useState<any>(null);

  useEffect(() => {
    let mounted = true;
    fetch("/api/region-analysis?lat=-89.9&lon=129.1")
      .then(res => {
        if (!res.ok) throw new Error("Server error");
        return res.json();
      })
      .then(data => {
        if (mounted) setReportData(data);
      })
      .catch(err => {
        console.warn("Failed to fetch report data:", err);
        if (mounted) {
           setReportData({
             confidence: 87,
             terrainSlope: 2.4,
             terrainRoughness: 12,
             riskLevel: 'Safe',
             distanceToIce: 1.4,
             illumination: 92,
             iceProbability: 72,
             temperature: 42
           });
        }
      });
    return () => { mounted = false; };
  }, []);

  const handleDownload = async (type: string) => {
    try {
      const res = await fetch("/api/report");
      const data = await res.json();
      console.log(`Downloading ${type} report...`);
      // Simulate download
    } catch(e) {
      console.error(e);
    }
  };

  return (
    <div className="w-full h-full bg-[#020408] overflow-y-auto p-8">
      <div className="max-w-5xl mx-auto">
        <header className="mb-8 border-b border-slate-800 pb-6">
          <h1 className="text-xl font-bold text-slate-200 tracking-widest uppercase flex items-center">
            <FileText className="w-5 h-5 mr-3 text-[#00F2FF]" />
            Mission Reports & Export
          </h1>
          <p className="text-[11px] text-slate-500 mt-2 font-mono uppercase tracking-widest">Generate and download comprehensive XAI-backed mission reports for ISRO review.</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-[#050810] border border-slate-800 rounded-sm p-6 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#00F2FF]/5 rounded-full blur-3xl -mr-10 -mt-10 transition-transform group-hover:scale-150"></div>
            <FileText className="w-6 h-6 text-[#00F2FF] mb-4" />
            <h3 className="text-[11px] font-bold text-slate-300 mb-2 uppercase tracking-widest">PDF Mission Report</h3>
            <p className="text-[10px] text-slate-500 mb-6 font-mono leading-relaxed">Complete overview including maps, AI confidence scores, and safety assessments.</p>
            <button onClick={() => handleDownload('pdf')} className="w-full bg-[#00F2FF10] hover:bg-[#00F2FF20] text-[#00F2FF] border border-[#00F2FF40] py-2.5 rounded-sm text-[10px] font-mono tracking-widest uppercase transition-colors flex items-center justify-center">
              <Download className="w-3 h-3 mr-2" /> Download PDF
            </button>
          </div>

          <div className="bg-[#050810] border border-slate-800 rounded-sm p-6 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-green-500/5 rounded-full blur-3xl -mr-10 -mt-10 transition-transform group-hover:scale-150"></div>
            <FileSpreadsheet className="w-6 h-6 text-green-400 mb-4" />
            <h3 className="text-[11px] font-bold text-slate-300 mb-2 uppercase tracking-widest">Raw Data (CSV)</h3>
            <p className="text-[10px] text-slate-500 mb-6 font-mono leading-relaxed">Tabular datasets of surface features, waypoints, and hazard coordinates.</p>
            <button onClick={() => handleDownload('csv')} className="w-full bg-slate-900 hover:bg-slate-800 text-green-400 py-2.5 rounded-sm text-[10px] font-mono tracking-widest uppercase transition-colors flex items-center justify-center border border-slate-800">
              <Download className="w-3 h-3 mr-2" /> Export CSV
            </button>
          </div>

          <div className="bg-[#050810] border border-slate-800 rounded-sm p-6 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/5 rounded-full blur-3xl -mr-10 -mt-10 transition-transform group-hover:scale-150"></div>
            <FileJson className="w-6 h-6 text-purple-400 mb-4" />
            <h3 className="text-[11px] font-bold text-slate-300 mb-2 uppercase tracking-widest">Model Params (JSON)</h3>
            <p className="text-[10px] text-slate-500 mb-6 font-mono leading-relaxed">Export SHAP values, weights, and ML configurations used for prediction.</p>
            <button onClick={() => handleDownload('json')} className="w-full bg-slate-900 hover:bg-slate-800 text-purple-400 py-2.5 rounded-sm text-[10px] font-mono tracking-widest uppercase transition-colors flex items-center justify-center border border-slate-800">
              <Download className="w-3 h-3 mr-2" /> Export JSON
            </button>
          </div>
        </div>

        <div className="bg-[#050810] border border-slate-800 rounded-sm p-6">
          <div className="flex justify-between items-center mb-6 pb-4 border-b border-slate-800">
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-widest">Report Preview</h2>
            <button className="bg-slate-900 hover:bg-slate-800 text-slate-300 px-4 py-2 rounded-sm text-[10px] font-mono tracking-widest uppercase transition-colors flex items-center border border-slate-800">
              <Share2 className="w-3 h-3 mr-2" /> Share Report
            </button>
          </div>

          <div className="bg-[#020408] rounded-sm border border-slate-800 p-8 font-serif text-slate-300 max-w-3xl mx-auto shadow-inner relative">
            <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-[#00F2FF] via-green-500 to-transparent"></div>
            <div className="text-center mb-8 border-b border-slate-800 pb-8">
              <h3 className="text-2xl font-bold text-slate-200 tracking-widest uppercase mb-2">ISRO Lunar Mission</h3>
              <p className="text-slate-500 font-mono text-[10px] uppercase tracking-widest">Generated by Lunar Mission Console</p>
              <p className="text-slate-500 font-mono text-[10px] uppercase tracking-widest mt-1">Date: {new Date().toISOString().split('T')[0]} | Target: Shackleton Crater</p>
            </div>
            
            {reportData ? (
              <div className="space-y-6">
                <section>
                  <h4 className="text-sm font-bold text-slate-200 mb-3 font-sans uppercase tracking-widest">1. Executive Summary</h4>
                  <p className="leading-relaxed text-[13px]">
                    The primary landing site at Shackleton Rim (89.9° S, 129.1° E) has been assessed with a safety score of {100 - reportData.terrainSlope * 2 - reportData.terrainRoughness}/100. 
                    Ice probability models indicate an {reportData.confidence}% confidence of surface water ice in the adjacent PSR (Permanently Shadowed Region).
                  </p>
                </section>
                
                <section>
                  <h4 className="text-sm font-bold text-slate-200 mb-3 font-sans uppercase tracking-widest">2. Landing Assessment</h4>
                  <ul className="list-none space-y-3 font-sans text-[13px]">
                    <li className="flex items-center">
                      <CheckCircle2 className={cn("w-4 h-4 mr-3", reportData.terrainRoughness < 15 ? "text-green-500" : "text-yellow-500")} /> 
                      Terrain Roughness: {reportData.terrainRoughness}%
                    </li>
                    <li className="flex items-center"><CheckCircle2 className="w-4 h-4 text-green-500 mr-3" /> Illumination: {reportData.illumination}% continuous</li>
                    <li className="flex items-center"><CheckCircle2 className="w-4 h-4 text-green-500 mr-3" /> Distance to Target: {reportData.distanceToIce}km</li>
                  </ul>
                </section>
              </div>
            ) : (
              <div className="text-center font-mono text-[10px] text-slate-500">Loading dynamic report data...</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
