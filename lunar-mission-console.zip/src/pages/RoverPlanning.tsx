import { useState, useEffect } from "react";
import { HoloMoon } from "../components/HoloMoon";
import { Navigation2, Play, Pause, RotateCcw, Download, Battery, Clock, AlertTriangle, Route, Users, Lock } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../lib/utils";
import { doc, onSnapshot, setDoc, updateDoc } from "firebase/firestore";
import { db } from "../lib/firebase";
import { useAuth } from "../context/AuthContext";

export function RoverPlanning() {
  const { profile } = useAuth();
  const [routeState, setRouteState] = useState<"idle" | "generating" | "generated" | "simulating">("idle");
  const [startPoint, setStartPoint] = useState("Shackleton Rim (Landing)");
  const [targetPoint, setTargetPoint] = useState("PSR-Alpha (Ice Deposit)");
  const [collaborators, setCollaborators] = useState<number>(1);
  const [routeStats, setRouteStats] = useState<any>(null);
  
  const planDocRef = doc(db, "mission_plans", "shackleton_primary");

  useEffect(() => {
    const unsubscribe = onSnapshot(planDocRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.routeState) setRouteState(data.routeState);
        if (data.startPoint) setStartPoint(data.startPoint);
        if (data.targetPoint) setTargetPoint(data.targetPoint);
        if (data.routeStats) setRouteStats(data.routeStats);
        setCollaborators(Math.max(1, Math.floor(Math.random() * 3) + 1)); 
      } else {
        try {
          setDoc(planDocRef, {
            routeState: "idle",
            startPoint: "Shackleton Rim (Landing)",
            targetPoint: "PSR-Alpha (Ice Deposit)",
            routeStats: null
          });
        } catch(e) {}
      }
    }, (error) => {
      console.error("Error fetching mission plan:", error);
    });
    return () => unsubscribe();
  }, []);

  const updateSharedState = async (updates: Partial<{routeState: string, startPoint: string, targetPoint: string, routeStats: any}>) => {
    try {
      await updateDoc(planDocRef, updates);
    } catch (error) {
      console.error("Error updating shared state:", error);
    }
  };
  
  const handleGenerate = async () => {
    if (profile?.role === 'data analyst') return;
    updateSharedState({ routeState: "generating" });
    
    try {
      const res = await fetch("/api/plan-route", {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ start: startPoint, target: targetPoint })
      });
      const data = await res.json();
      
      setTimeout(() => {
        updateSharedState({ routeState: "generated", routeStats: data });
      }, 2000);
    } catch (e) {
      console.error(e);
      setTimeout(() => {
        updateSharedState({ routeState: "idle" });
      }, 1000);
    }
  };
  
  const canModify = profile?.role === 'mission planner' || profile?.role === 'administrator';

  return (
    <div className="w-full h-full relative overflow-hidden bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#0A1120] to-[#020408]">
      <HoloMoon />
      
      {/* Route Animation Simulation */}
      <AnimatePresence>
        {(routeState === "generated" || routeState === "simulating") && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 pointer-events-none flex items-center justify-center z-0"
          >
            <svg width="400" height="300" viewBox="0 0 400 300" className="absolute" style={{ transform: 'rotateX(60deg) rotateZ(30deg)' }}>
              {/* Fake route path */}
              <path 
                d="M 50 250 Q 150 200 200 150 T 350 50" 
                fill="none" 
                stroke="#00F2FF" 
                strokeWidth="2" 
                strokeDasharray="4 4"
                className="opacity-30"
              />
              <motion.path 
                d="M 50 250 Q 150 200 200 150 T 350 50" 
                fill="none" 
                stroke="#00F2FF" 
                strokeWidth="3" 
                strokeLinecap="square"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 2, ease: "easeInOut" }}
                style={{ filter: "drop-shadow(0 0 8px #00F2FF)" }}
              />
              
              {/* Rover Indicator during simulation */}
              {routeState === "simulating" && (
                <motion.circle
                  r="4"
                  fill="#FFF"
                  initial={{ offsetDistance: "0%" }}
                  animate={{ offsetDistance: "100%" }}
                  transition={{ duration: 10, ease: "linear", repeat: Infinity }}
                  style={{
                    offsetPath: "path('M 50 250 Q 150 200 200 150 T 350 50')",
                    filter: "drop-shadow(0 0 10px #FFF)"
                  }}
                />
              )}
            </svg>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="absolute left-8 top-8 bottom-16 w-[360px] bg-[#050810]/90 backdrop-blur-xl border border-slate-800 rounded-sm p-5 flex flex-col pointer-events-auto shadow-2xl z-10">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-sm font-bold text-slate-200 flex items-center uppercase tracking-widest">
            <Navigation2 className="w-4 h-4 mr-2 text-[#00F2FF]" />
            Autonomous Rover Path
          </h2>
          <div className="flex items-center text-[9px] text-[#00F2FF] font-mono tracking-widest bg-[#00F2FF10] border border-[#00F2FF40] px-2 py-1 rounded-sm">
            <Users className="w-3 h-3 mr-1" />
            {collaborators} ONLINE
          </div>
        </div>

        <div className="space-y-4 mb-6">
          <div className="bg-slate-900/50 p-3 rounded-sm border border-slate-800">
            <label className="text-[10px] text-slate-500 mb-1 block uppercase tracking-widest font-bold">Start Point</label>
            <div className="flex items-center justify-between">
              <span className="text-slate-200 font-mono text-xs uppercase">{startPoint}</span>
              {canModify && <button className="text-[#00F2FF] text-[10px] hover:text-white uppercase tracking-widest">Edit</button>}
            </div>
          </div>
          
          <div className="flex justify-center -my-2 relative z-10">
            <div className="w-6 h-6 rounded-sm bg-slate-900 border border-slate-700 flex items-center justify-center text-slate-500">
              <Route className="w-3 h-3" />
            </div>
          </div>

          <div className="bg-slate-900/50 p-3 rounded-sm border border-slate-800">
            <label className="text-[10px] text-slate-500 mb-1 block uppercase tracking-widest font-bold">Target Point</label>
            <div className="flex items-center justify-between">
              <span className="text-slate-200 font-mono text-xs uppercase">{targetPoint}</span>
              {canModify && <button className="text-[#00F2FF] text-[10px] hover:text-white uppercase tracking-widest">Edit</button>}
            </div>
          </div>
        </div>

        {routeState === "idle" && (
          <div className="mt-auto pt-4 border-t border-slate-800">
            {canModify ? (
              <button 
                onClick={handleGenerate}
                className="w-full bg-[#00F2FF10] hover:bg-[#00F2FF20] text-[#00F2FF] font-mono text-[11px] uppercase tracking-widest py-3 rounded-sm transition-colors flex items-center justify-center border border-[#00F2FF40]"
              >
                <Navigation2 className="w-4 h-4 mr-2" />
                Generate Optimal Route
              </button>
            ) : (
              <button 
                disabled
                className="w-full bg-slate-900 text-slate-500 font-mono text-[11px] uppercase tracking-widest py-3 rounded-sm flex items-center justify-center border border-slate-800 cursor-not-allowed"
              >
                <Lock className="w-4 h-4 mr-2" />
                Auth Required
              </button>
            )}
          </div>
        )}

        {routeState === "generating" && (
          <div className="mt-auto pt-4 border-t border-slate-800">
            <button disabled className="w-full bg-slate-800 text-[#00F2FF] border border-[#00F2FF40] font-mono text-[11px] uppercase tracking-widest py-3 rounded-sm flex items-center justify-center relative overflow-hidden">
              <motion.div 
                className="absolute left-0 top-0 bottom-0 bg-[#00F2FF30]" 
                initial={{ width: "0%" }}
                animate={{ width: "100%" }}
                transition={{ duration: 2 }}
              />
              <span className="relative flex items-center">
                <div className="w-3 h-3 rounded-full border border-t-transparent border-[#00F2FF] animate-spin mr-2"></div>
                Calculating A* Path...
              </span>
            </button>
          </div>
        )}

        {(routeState === "generated" || routeState === "simulating") && routeStats && (
          <div className="flex-1 flex flex-col pt-4 border-t border-slate-800">
            <div className="bg-slate-900/50 rounded-sm p-4 border border-slate-800 mb-4 flex-1">
              <h3 className="text-[10px] uppercase font-bold tracking-widest text-slate-500 mb-4">Route Analytics</h3>
              
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="bg-slate-900/40 p-2 rounded-sm border border-slate-800">
                  <div className="flex items-center text-slate-500 text-[10px] uppercase tracking-widest mb-1">
                    <Clock className="w-3 h-3 mr-1" /> ETA
                  </div>
                  <div className="text-lg font-mono text-slate-200">{routeStats.eta}</div>
                </div>
                <div className="bg-slate-900/40 p-2 rounded-sm border border-slate-800">
                  <div className="flex items-center text-slate-500 text-[10px] uppercase tracking-widest mb-1">
                    <Battery className="w-3 h-3 mr-1" /> Energy Est.
                  </div>
                  <div className="text-lg font-mono text-yellow-400">{routeStats.energy} <span className="text-[10px] text-yellow-600">kWh</span></div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold mb-2">Hazards Avoided</div>
                <div className="flex items-center text-[11px] font-mono text-slate-300">
                  <AlertTriangle className="w-3 h-3 mr-2 text-orange-400" />
                  {routeStats.hazards.slopes} Steep Slopes ({'>'}15°)
                </div>
                <div className="flex items-center text-[11px] font-mono text-slate-300">
                  <AlertTriangle className="w-3 h-3 mr-2 text-orange-400" />
                  {routeStats.hazards.boulders} Large Boulder Field{routeStats.hazards.boulders !== 1 ? 's' : ''}
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex space-x-2">
                {routeState === "generated" ? (
                  <button 
                    onClick={() => updateSharedState({ routeState: "simulating" })}
                    disabled={!canModify}
                    className={cn("flex-1 font-mono text-[10px] uppercase tracking-widest py-2 rounded-sm transition-colors flex items-center justify-center border",
                      canModify ? "bg-green-500/10 hover:bg-green-500/20 border-green-500/40 text-green-400" : "bg-slate-900 border-slate-800 text-slate-600 cursor-not-allowed")}
                  >
                    <Play className="w-3 h-3 mr-1" /> Start Sim
                  </button>
                ) : (
                  <button 
                    onClick={() => updateSharedState({ routeState: "generated" })}
                    disabled={!canModify}
                    className={cn("flex-1 font-mono text-[10px] uppercase tracking-widest py-2 rounded-sm transition-colors flex items-center justify-center border",
                      canModify ? "bg-orange-500/10 hover:bg-orange-500/20 border-orange-500/40 text-orange-400" : "bg-slate-900 border-slate-800 text-slate-600 cursor-not-allowed")}
                  >
                    <Pause className="w-3 h-3 mr-1" /> Pause
                  </button>
                )}
                <button 
                  onClick={() => updateSharedState({ routeState: "idle" })}
                  disabled={!canModify}
                  className={cn("font-medium p-2 rounded-sm transition-colors flex items-center justify-center w-10 border",
                    canModify ? "bg-slate-900 hover:bg-slate-800 border-slate-800 text-slate-400" : "bg-slate-900/50 border-slate-800/50 text-slate-600 cursor-not-allowed")}
                >
                  <RotateCcw className="w-3 h-3" />
                </button>
              </div>
              <button className="w-full bg-slate-900 hover:bg-slate-800 text-slate-400 py-2 rounded-sm text-[10px] font-mono uppercase tracking-widest transition-colors border border-slate-800 flex items-center justify-center">
                <Download className="w-3 h-3 mr-2" />
                Download GeoJSON
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
