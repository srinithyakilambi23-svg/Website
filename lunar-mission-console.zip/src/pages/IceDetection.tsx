import React, { useState, useEffect, useRef } from "react";
import { HoloMoon } from "../components/HoloMoon";
import { Layers, Upload, Download, Activity, Cpu, CheckCircle2, AlertTriangle, XCircle, FileText, Share2, ZoomIn, Map } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../lib/utils";
import { useDropzone } from "react-dropzone";
import { Bar } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from "chart.js";
import { validateGeoTIFF } from "../lib/geoTiffValidator";
import { db } from "../lib/firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const DATASETS_CONFIG = [
  { id: "dfsar", name: "DFSAR", type: "Radar", active: true },
  { id: "lola", name: "LOLA", type: "DEM", active: true },
  { id: "diviner", name: "Diviner", type: "Temperature", active: false },
  { id: "lend", name: "LEND", type: "Hydrogen", active: false },
  { id: "minirf", name: "Mini-RF", type: "Radar", active: true },
  { id: "m3", name: "M3", type: "Spectral", active: false },
];

export function IceDetection() {
  const [datasets, setDatasets] = useState(DATASETS_CONFIG.map(d => ({ ...d, uploaded: d.active, status: d.active ? 'uploaded' : 'missing' })));
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStatus, setProcessingStatus] = useState("");
  const [processingProgress, setProcessingProgress] = useState(0);
  const [showHeatmap, setShowHeatmap] = useState(false);
  const [statistics, setStatistics] = useState<any>(null);

  const onDrop = async (acceptedFiles: File[]) => {
    if (acceptedFiles.length === 0) return;
    const file = acceptedFiles[0];
    
    const dsId = datasets.find(d => !d.uploaded)?.id || "dfsar";
    setDatasets(datasets.map(d => d.id === dsId ? { ...d, status: 'processing' } : d));

    const validation = await validateGeoTIFF(file);
    if (!validation.isValid) {
       console.error("Validation failed:", validation.error);
       setDatasets(datasets.map(d => d.id === dsId ? { ...d, status: 'missing' } : d));
       try {
         await addDoc(collection(db, "notifications"), {
           message: `Invalid file: ${validation.error}`,
           type: "error",
           createdAt: serverTimestamp()
         });
       } catch (e) {}
       return;
    }

    const formData = new FormData();
    formData.append("file", file);
    
    try {
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      if (res.ok) {
        setDatasets(datasets.map(d => d.id === dsId ? { ...d, uploaded: true, status: 'uploaded', active: true } : d));
        try {
          await addDoc(collection(db, "notifications"), {
            message: `Dataset uploaded: ${file.name}`,
            type: "success",
            createdAt: serverTimestamp()
          });
        } catch (e) {
          console.error("Failed to add notification:", e);
        }
      }
    } catch (e) {
      console.error(e);
      setDatasets(datasets.map(d => d.id === dsId ? { ...d, status: 'missing' } : d));
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });

  const toggleDataset = (id: string) => {
    setDatasets(datasets.map(d => d.id === id ? { ...d, active: !d.active } : d));
  };

  const handleGenerate = async () => {
    setIsProcessing(true);
    setShowHeatmap(false);
    setProcessingStatus("Initializing pipeline...");
    setProcessingProgress(10);

    try {
      const res = await fetch("/api/generate-ice-map", { method: "POST" });
      const data = await res.json();
      const taskId = data.taskId;

      const poll = setInterval(async () => {
        const statRes = await fetch(`/api/task-status/${taskId}`);
        const statData = await statRes.json();
        
        setProcessingStatus(statData.status);
        setProcessingProgress(statData.progress);

        if (statData.progress === 100) {
          clearInterval(poll);
          if (statData.results) {
            setStatistics(statData.results);
            setIsProcessing(false);
            setShowHeatmap(true);
            try {
              await addDoc(collection(db, "notifications"), {
                message: `Ice Probability Map Generated: ${statData.results.confidence}% confidence`,
                type: "success",
                createdAt: serverTimestamp()
              });
            } catch(e) {
              console.error("Failed to add notification:", e);
            }
          }
        } else if (statData.progress === -1) {
           clearInterval(poll);
           setProcessingStatus("Pipeline Error");
           setIsProcessing(false);
        }
      }, 2000);
    } catch (e) {
      setProcessingStatus("Failed to run ML model");
      setIsProcessing(false);
    }
  };

  const [regionData, setRegionData] = useState<any>(null);
  
  // Expose this so HoloMoon could call it, or simulate a click for now
  const handleRegionClick = async (lat: number, lon: number) => {
    try {
      const res = await fetch(`/api/region-analysis?lat=${lat}&lon=${lon}`);
      const data = await res.json();
      setRegionData({ ...data, lat, lon });
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    // If heatmap shows up, trigger a default region click just to show it's dynamic
    if (showHeatmap && !regionData) {
      handleRegionClick(-89.9, 129.1);
    }
  }, [showHeatmap]);

  const chartData = {
    labels: statistics?.featureImportance.map((f: any) => f.label) || [],
    datasets: [
      {
        label: "Feature Importance (%)",
        data: statistics?.featureImportance.map((f: any) => f.value) || [],
        backgroundColor: "#00F2FF",
        borderColor: "#00F2FF",
        borderWidth: 1,
      },
    ],
  };

  const chartOptions = {
    indexAxis: 'y' as const,
    responsive: true,
    scales: {
      x: { grid: { color: "#1e293b" }, ticks: { color: "#64748b" } },
      y: { grid: { display: false }, ticks: { color: "#94a3b8", font: { family: "monospace", size: 10 } } }
    },
    plugins: {
      legend: { display: false },
    }
  };

  return (
    <div className="w-full h-full relative overflow-hidden bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#0A1120] to-[#020408]">
      <HoloMoon showHeatmap={showHeatmap} onPointClick={handleRegionClick} />

      {showHeatmap && (
        <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#00F2FF]/10 to-transparent mix-blend-screen transition-opacity duration-1000 z-0"></div>
      )}

      {/* Left Data Panel */}
      <div className="absolute left-6 top-6 bottom-6 w-80 bg-[#050810]/90 backdrop-blur-xl border border-slate-800 rounded-sm p-4 flex flex-col pointer-events-auto shadow-2xl z-10 overflow-y-auto custom-scrollbar">
        <h2 className="text-sm font-bold text-slate-200 mb-6 flex items-center uppercase tracking-widest">
          <Layers className="w-4 h-4 mr-2 text-[#00F2FF]" />
          Dataset Manager
        </h2>

        <div className="space-y-2 mb-6">
          {datasets.map(ds => (
            <div key={ds.id} className="bg-slate-900/50 border border-slate-800 rounded-sm p-3">
              <div className="flex justify-between items-center mb-2">
                <div>
                  <span className="font-mono text-[11px] font-bold text-slate-300 tracking-wider uppercase">{ds.name}</span>
                  <span className="block text-[9px] text-slate-500 uppercase tracking-widest">{ds.type}</span>
                </div>
                {ds.status === 'uploaded' ? (
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                ) : ds.status === 'processing' ? (
                  <div className="w-3 h-3 border border-t-transparent border-[#00F2FF] rounded-full animate-spin"></div>
                ) : (
                  <XCircle className="w-4 h-4 text-slate-600" />
                )}
              </div>
              <div className="flex items-center justify-between">
                <label className="text-[10px] text-slate-400 font-mono uppercase tracking-widest flex items-center gap-2">
                  <input 
                    type="checkbox" 
                    checked={ds.active} 
                    onChange={() => toggleDataset(ds.id)}
                    disabled={!ds.uploaded}
                    className="accent-[#00F2FF] bg-slate-800"
                  />
                  Layer Visibility
                </label>
                {ds.uploaded && (
                  <input type="range" min="0" max="100" defaultValue="100" className="w-16 accent-[#00F2FF]" />
                )}
              </div>
            </div>
          ))}
        </div>

        <div 
          {...getRootProps()} 
          className={cn(
            "mt-auto border border-dashed rounded-sm p-6 flex flex-col items-center justify-center cursor-pointer transition-colors",
            isDragActive ? "border-[#00F2FF] bg-[#00F2FF10]" : "border-slate-700 hover:border-slate-500 hover:bg-slate-900/50"
          )}
        >
          <input {...getInputProps()} />
          <Upload className="w-6 h-6 mb-3 text-slate-500" />
          <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 text-center">
            {isDragActive ? "Drop GeoTIFF here" : "Drag & Drop GeoTIFF\nor click to browse"}
          </span>
        </div>
      </div>

      {/* Right Processing & Stats Panel */}
      <div className="absolute right-6 top-6 bottom-6 w-[360px] bg-[#050810]/90 backdrop-blur-xl border border-slate-800 rounded-sm p-4 flex flex-col pointer-events-auto shadow-2xl z-10 overflow-y-auto custom-scrollbar">
        <h2 className="text-sm font-bold text-slate-200 mb-6 flex items-center uppercase tracking-widest">
          <Activity className="w-4 h-4 mr-2 text-[#00F2FF]" />
          AI Processing
        </h2>

        <button 
          onClick={handleGenerate}
          disabled={isProcessing}
          className="w-full bg-[#00F2FF10] hover:bg-[#00F2FF20] disabled:bg-slate-900 disabled:border-slate-800 border border-[#00F2FF40] text-[#00F2FF] disabled:text-slate-500 font-mono text-[11px] tracking-widest uppercase py-3 rounded-sm transition-colors flex items-center justify-center relative overflow-hidden mb-6"
        >
          <Cpu className={cn("w-4 h-4 mr-2", isProcessing && "animate-pulse")} />
          Generate Ice Probability
          {isProcessing && (
            <motion.div 
              className="absolute left-0 bottom-0 h-1 bg-[#00F2FF]" 
              style={{ width: `${processingProgress}%` }}
              transition={{ ease: "linear", duration: 0.5 }}
            />
          )}
        </button>

        {isProcessing && (
          <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-sm mb-6">
            <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Pipeline Status</h3>
            <div className="space-y-3">
              {[
                { step: "Read GeoTIFF", threshold: 10 },
                { step: "Align datasets", threshold: 30 },
                { step: "Generate features", threshold: 50 },
                { step: "Run ML Model", threshold: 70 },
                { step: "Create heatmap", threshold: 90 }
              ].map((s, i) => (
                <div key={i} className="flex items-center text-[10px] font-mono">
                  {processingProgress > s.threshold ? (
                    <CheckCircle2 className="w-3 h-3 text-green-500 mr-2" />
                  ) : processingProgress >= (s.threshold - 10) ? (
                    <div className="w-3 h-3 border border-t-transparent border-[#00F2FF] rounded-full animate-spin mr-2"></div>
                  ) : (
                    <div className="w-3 h-3 border border-slate-700 rounded-full mr-2"></div>
                  )}
                  <span className={processingProgress >= (s.threshold - 10) ? "text-[#00F2FF]" : "text-slate-600"}>{s.step}</span>
                </div>
              ))}
            </div>
            <div className="mt-4 text-[10px] text-slate-400 font-mono text-right">{processingProgress}%</div>
          </div>
        )}

        {statistics && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex-1 flex flex-col"
          >
            <div className="grid grid-cols-2 gap-3 mb-6">
              <div className="bg-slate-900/50 p-3 rounded-sm border border-slate-800 text-center">
                <div className="text-[10px] text-slate-500 uppercase tracking-widest mb-1">Ice Prob</div>
                <div className="text-xl font-bold text-[#00F2FF] font-mono">{statistics.iceProbability}%</div>
              </div>
              <div className="bg-slate-900/50 p-3 rounded-sm border border-slate-800 text-center">
                <div className="text-[10px] text-slate-500 uppercase tracking-widest mb-1">Confidence</div>
                <div className="text-xl font-bold text-green-400 font-mono">{statistics.confidence}%</div>
              </div>
              <div className="bg-slate-900/50 p-3 rounded-sm border border-slate-800 text-center">
                <div className="text-[10px] text-slate-500 uppercase tracking-widest mb-1">Temperature</div>
                <div className="text-sm font-bold text-orange-400 font-mono">{statistics.temperature} K</div>
              </div>
              <div className="bg-slate-900/50 p-3 rounded-sm border border-slate-800 text-center">
                <div className="text-[10px] text-slate-500 uppercase tracking-widest mb-1">Hydrogen</div>
                <div className="text-sm font-bold text-purple-400 font-mono">{statistics.hydrogen}</div>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">SHAP Feature Importance</h3>
              <div className="h-40 bg-slate-900/30 p-2 rounded-sm border border-slate-800">
                <Bar data={chartData} options={chartOptions} />
              </div>
            </div>

            <div className="mt-auto space-y-2">
              <div className="flex gap-2">
                <button className="flex-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 py-2 rounded-sm text-[10px] font-mono uppercase tracking-widest transition-colors flex items-center justify-center">
                  <Map className="w-3 h-3 mr-2" />
                  Compare
                </button>
                <button className="flex-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[#00F2FF] py-2 rounded-sm text-[10px] font-mono uppercase tracking-widest transition-colors flex items-center justify-center">
                  <Download className="w-3 h-3 mr-2" />
                  Heatmap
                </button>
              </div>
              <button className="w-full bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 py-2 rounded-sm text-[10px] font-mono uppercase tracking-widest transition-colors flex items-center justify-center">
                <FileText className="w-3 h-3 mr-2" />
                Export Results (PDF/CSV)
              </button>
            </div>
          </motion.div>
        )}
      </div>
      
      {/* Heatmap Legend */}
      <AnimatePresence>
        {showHeatmap && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-[#050810]/90 backdrop-blur-md border border-slate-800 rounded-sm p-4 pointer-events-auto shadow-2xl"
          >
            <h3 className="text-[10px] font-bold text-slate-300 mb-3 uppercase tracking-widest text-center">Ice Probability Heatmap</h3>
            <div className="flex items-center h-3 w-80 bg-gradient-to-r from-red-500 via-purple-500 to-[#00F2FF] rounded-sm mb-2"></div>
            <div className="flex justify-between text-[9px] font-mono text-slate-500 uppercase tracking-widest">
              <span>Low (Red)</span>
              <span>Medium (Purple)</span>
              <span>High (Cyan)</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Region Popup (Simulated selection on a point) */}
      <AnimatePresence>
        {showHeatmap && regionData && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-[#050810]/95 backdrop-blur-xl border border-[#00F2FF40] rounded-sm p-4 shadow-[0_0_30px_rgba(0,242,255,0.15)] pointer-events-auto z-20 w-72"
          >
            <div className="flex justify-between items-start mb-4 border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-[#00F2FF] uppercase tracking-widest">Selected Region</h3>
                <p className="text-[10px] text-slate-500 font-mono tracking-widest">LAT: {regionData.lat}° S | LON: {regionData.lon}° E</p>
              </div>
              <button onClick={() => setRegionData(null)} className="text-slate-500 hover:text-white"><XCircle className="w-4 h-4" /></button>
            </div>
            <div className="grid grid-cols-2 gap-x-6 gap-y-3 text-[11px] font-mono">
              <div className="flex justify-between text-slate-400"><span>Ice Prob:</span> <span className="text-[#00F2FF] font-bold">{regionData.iceProbability}%</span></div>
              <div className="flex justify-between text-slate-400"><span>Conf:</span> <span className="text-green-400">{regionData.confidence}%</span></div>
              <div className="flex justify-between text-slate-400"><span>Hydrogen:</span> <span>{regionData.hydrogen}</span></div>
              <div className="flex justify-between text-slate-400"><span>Temp:</span> <span className="text-orange-400">{regionData.temperature} K</span></div>
              <div className="flex justify-between text-slate-400"><span>Slope:</span> <span className="text-yellow-400">{regionData.terrainSlope}°</span></div>
              <div className="flex justify-between text-slate-400"><span>Risk:</span> <span className={regionData.riskLevel === 'Danger' ? 'text-red-400' : 'text-green-400'}>{regionData.riskLevel}</span></div>
            </div>
            <button className="w-full mt-4 bg-slate-900 border border-slate-800 text-slate-300 py-1.5 text-[10px] font-mono tracking-widest uppercase hover:bg-slate-800">
              Set as Target
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
